﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Xml.Serialization;
namespace AIM.Common.Types.MindBody
{
    [XmlRoot(Namespace = "http://clients.mindbodyonline.com/API/0_4")]
    public class Result_RecordSet
    {

    }
}
