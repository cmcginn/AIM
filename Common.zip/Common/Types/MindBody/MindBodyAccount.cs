﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace AIM.Common.Types.MindBody
{
    public class MindBodyAccount
    {
        public string Sourcename { get; set; }
        public string Password { get; set; }
        public string StudioID { get; set; }
    }
}
