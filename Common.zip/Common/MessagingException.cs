﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.Serialization;
namespace AIM.Common
{
    public class MessagingException:AIMException
    {
        public MessagingException()
        {
            // Add implementation.
        }
        public MessagingException(string message)
        {
            // Add implementation.
        }
        public MessagingException(string message, Exception inner)
        {
            // Add implementation.
        }
        public MessagingException(string message, Exception inner,string request,string response)
        {
            // Add implementation.
        }
        // This constructor is needed for serialization.
        protected MessagingException(SerializationInfo info, StreamingContext context)
        {
            // Add implementation.
        }
    }
}
